---@class AddonMessageType
MotdAddon_Types_MessageType = {
    DisplayAbilityName = 1001
}