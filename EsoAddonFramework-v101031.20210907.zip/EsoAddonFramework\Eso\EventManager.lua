---@class EventManager
EsoAddonFramework_Framework_Eso_EventManager = EVENT_MANAGER
