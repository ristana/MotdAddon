---@class StorageScope
EsoAddonFramework_Framework_StorageScope = {
    Account = 1,
    Character = 2
}