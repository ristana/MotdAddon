---@class UnitTag
EsoAddonFramework_Framework_Eso_UnitTag = {
    Companion = "companion",
    Interact = "interact",
    Player = "player",
    ---The unit that the reticle is over
    ReticleOver = "reticleover",
    ---The unit that ReticleOver is targeting
    ReticleOverTarget = "reticleovertarget"
}