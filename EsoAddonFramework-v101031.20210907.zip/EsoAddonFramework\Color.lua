---@class Color
EsoAddonFramework_Framework_Color = {
    Blue      = "00ffff",
    Gray      = "888888",
    Green     = "00ff00",
    Orange    = "ff8c00",
    Purple    = "9932cc",
    Red       = "ff2222",
    White     = "eeeeee",
    Yellow    = "ffff00"
}